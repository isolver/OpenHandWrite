"""
Coder is the python IDE for PsychoPy
"""
from __future__ import absolute_import
from .coder import *  # pylint: disable=W0401
