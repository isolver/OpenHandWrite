# Part of the PsychoPy library
# Copyright (C) 2015 Jonathan Peirce
# Distributed under the terms of the GNU General Public License (GPL).
from . import preferences as prefsLib
Preferences, prefs = prefsLib.Preferences, prefsLib.prefs #class for loading/saving prefs
