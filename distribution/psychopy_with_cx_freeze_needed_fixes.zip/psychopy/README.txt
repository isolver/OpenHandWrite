Thanks for downloading PsychoPy!

MORE INFO:
See the documentation at
	http://www.psychopy.org
and run the included demos.

FEEDBACK:
I would really appreciate your feedback. What things would you like added? What should be done differently?

Join the mailing list at:
    http://groups.google.com/group/psychopy-users
Report bugs at:
    http://code.google.com/p/psychopy/issues
