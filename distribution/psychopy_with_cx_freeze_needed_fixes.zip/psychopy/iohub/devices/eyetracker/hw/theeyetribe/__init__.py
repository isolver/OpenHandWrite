"""
ioHub
Common Eye Tracker Interface for TheEyeTribe system.
.. file: ioHub/devices/eyetracker/hw/theeyetribe/__init__.py

Copyright (C) 2012-2014 iSolver Software Solutions
Distributed under the terms of the GNU General Public License (GPL version 3 or any later version).

.. moduleauthor:: ??
.. fileauthor:: ??
"""

from eyetracker import *
